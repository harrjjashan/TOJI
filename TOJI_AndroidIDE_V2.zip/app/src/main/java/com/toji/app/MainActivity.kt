package com.toji.app

import android.app.*
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.*
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("toji", MODE_PRIVATE) }
    private val purple = Color.rgb(178, 105, 255)
    private val bg = Color.rgb(8, 6, 13)
    private val card = Color.rgb(18, 15, 24)
    private lateinit var streak: TextView
    private lateinit var level: TextView
    private lateinit var xpText: TextView
    private lateinit var quote: TextView
    private lateinit var content: LinearLayout

    private val quotes = listOf(
        "Discipline beats motivation.",
        "Nobody is coming to save you.",
        "Become someone your old self would fear.",
        "One clean day. Then another.",
        "Control the urge. Keep the streak.",
        "Don't negotiate with yourself.",
        "You don't need more stimulation. You need purpose.",
        "Weak moment. Strong decision.",
        "Get off the screen. Get on your feet.",
        "The old you would give in. Don't be the old you."
    )

    private val boredChallenges = listOf(
        "20 push-ups", "1,000 steps", "10-minute walk",
        "Clean your room for 5 minutes", "Study for 10 minutes",
        "20 squats", "Drink 500ml water", "Put your phone away for 15 minutes"
    )

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        showHome()
    }

    private fun tv(text:String, size:Float, color:Int=Color.WHITE, bold:Boolean=false):TextView =
        TextView(this).apply {
            this.text=text; textSize=size; setTextColor(color)
            if(bold) typeface=Typeface.DEFAULT_BOLD
            setPadding(4,5,4,5)
        }

    private fun button(text:String, action:()->Unit)=Button(this).apply{
        this.text=text; setTextColor(Color.WHITE); setOnClickListener{action()}
    }

    private fun showHome(){
        content=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(24,24,24,80);setBackgroundColor(bg)}
        val scroll=ScrollView(this);scroll.addView(content)

        content.addView(tv("TOJI",38,Color.WHITE,true))
        content.addView(tv("DISCIPLINE. NOT MOTIVATION.",10,Color.LTGRAY))
        quote=tv("“${quotes.random()}”",19,Color.WHITE,true)
        content.addView(quote,lp(140,18))

        val lvl=prefs.getInt("level",1); val xp=prefs.getInt("xp",0); val next=lvl*100
        level=tv("TOJI LEVEL $lvl",17,purple,true);content.addView(level)
        xpText=tv("$xp / $next XP",12,Color.LTGRAY);content.addView(xpText)
        val bar=ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal)
        bar.max=next;bar.progress=xp;content.addView(bar,lp(10,5))

        content.addView(tv("NO FAP STREAK",12,Color.LTGRAY).apply{gravity=Gravity.CENTER},lp(50,18))
        streak=tv("${prefs.getInt("streak",0)}",64,purple,true).apply{gravity=Gravity.CENTER}
        content.addView(streak)
        content.addView(tv("DAYS",12,Color.WHITE,true).apply{gravity=Gravity.CENTER})

        content.addView(button("🔥 I DIDN'T FAP TODAY"){cleanToday()},lp(60,10))
        content.addView(button("⚔ NEW MOTIVATIONAL QUOTE"){quote.text="“${quotes.random()}”"},lp(60,6))
        content.addView(button("🗿 I'M BORED"){boredMode()},lp(60,6))
        content.addView(button("🎁 REWARDS"){rewards()},lp(60,6))
        content.addView(button("📊 STATS"){stats()},lp(60,6))

        setContentView(scroll)
    }

    private fun boredMode(){
        val c=boredChallenges.random()
        AlertDialog.Builder(this).setTitle("I'M BORED 🗿")
            .setMessage("“${quotes.random()}”\n\n⚡ CHALLENGE\n$c\n\nDo it now. Then come back.")
            .setPositiveButton("DONE +10 XP"){_,_->addXp(10)}
            .setNegativeButton("ANOTHER",null).show()
    }

    private fun rewards(){
        val lvl=prefs.getInt("level",1)
        if(lvl%3!=0){toast("Reward unlocks every 3 levels. Current: Level $lvl")}
        else AlertDialog.Builder(this).setTitle("🎁 REWARD UNLOCKED")
            .setMessage("You reached Level $lvl.\n\nChoose your reward:\n🥤 Sting\n🎮 Gaming time\n🎬 Movie/episode\n🍔 Favourite meal\n✨ Custom reward")
            .setPositiveButton("CLAIM"){_,_->toast("Reward claimed 🗿")}.show()
    }

    private fun cleanToday(){
        val today=SimpleDateFormat("yyyy-MM-dd",Locale.US).format(Date())
        if(prefs.getString("lastDay","")==today){toast("Already checked in today.");return}
        var s=prefs.getInt("streak",0)+1
        val best=maxOf(s,prefs.getInt("best",0))
        prefs.edit().putString("lastDay",today).putInt("streak",s).putInt("best",best).apply()
        addXp(25);streak.text="$s";toast("CLEAN DAY +25 XP 🔥")
    }

    private fun addXp(amount:Int){
        var xp=prefs.getInt("xp",0)+amount
        var lvl=prefs.getInt("level",1)
        while(xp>=lvl*100){xp-=lvl*100;lvl++;toast("LEVEL UP! TOJI LEVEL $lvl 🗿")}
        prefs.edit().putInt("xp",xp).putInt("level",lvl).apply()
        level.text="TOJI LEVEL $lvl";xpText.text="$xp / ${lvl*100} XP"
    }

    private fun stats(){
        val s=prefs.getInt("streak",0);val best=prefs.getInt("best",0);val xp=prefs.getInt("xp",0);val lvl=prefs.getInt("level",1)
        AlertDialog.Builder(this).setTitle("TOJI STATS")
            .setMessage("Current streak: $s days\nBest streak: $best days\nLevel: $lvl\nXP: $xp\n\nKeep building.")
            .setPositiveButton("BACK",null).show()
    }

    private fun lp(h:Int,top:Int)=LinearLayout.LayoutParams(-1,h).apply{setMargins(0,top,0,0)}
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()
}
