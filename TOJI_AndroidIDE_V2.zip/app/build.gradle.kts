plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android { namespace="com.toji.app"; compileSdk=35
 defaultConfig { applicationId="com.toji.app"; minSdk=24; targetSdk=35; versionCode=2; versionName="2.0" }
}
